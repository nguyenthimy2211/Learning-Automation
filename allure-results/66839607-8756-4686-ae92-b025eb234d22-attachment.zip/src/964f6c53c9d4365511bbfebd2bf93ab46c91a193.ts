import { test } from "../../../pages/base-page";

const username: string = 'John Doe';
const password: string = 'ThisIsNotAPassword';



test.describe('Login Page Tests', () => {
    test('should login successfully with valid credentials', async ({ homePage, loginPage }) => {
        await homePage.goto();
        await homePage.clickMakeAppointment();
        await loginPage.login(username, password);
        // Add assertions to verify successful login
    });
});
