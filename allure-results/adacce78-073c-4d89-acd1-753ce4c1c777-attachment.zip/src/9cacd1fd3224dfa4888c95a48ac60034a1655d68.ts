import { HomePage } from "./ui/home-page";
import { LoginPage } from "./ui/login-page";
import {test as baseTest} from "@playwright/test";

export const test = baseTest.extend<{
    loginPage: LoginPage;
    homePage: HomePage;
}>({
    loginPage: async ({ page }, use) => {
        const instance = new LoginPage(page);
        await use(instance);
    },
    homePage: async ({ page }, use) => {
        const homePage = new HomePage(page);
        await use(homePage);
    }
});
