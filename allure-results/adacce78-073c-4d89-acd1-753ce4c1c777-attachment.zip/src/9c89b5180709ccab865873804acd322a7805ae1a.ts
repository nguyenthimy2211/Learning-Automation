import { Locator, Page } from "@playwright/test";
import { CommonLocators } from "../../locators/common-locators";



export class CommonPage extends CommonLocators {
    constructor(page: Page) {
        super(page);
    }
    //for report
    private describeLoactor(locator: Locator): string {
        try {
            return locator.toString();
        }
        catch (error) {
            return "Locator not found";
        }
    }
    /**
    * Go to the URL
    * @param {string} url
    * @param {boolean} isWait - Add a short settle delay after the load state (default true)
    * @param {'load'|'domcontentloaded'|'commit'} waitUntil - Navigation wait condition
    * @param {number} [timeout] - Navigation timeout in ms. Pass a short value when the
    *   caller wraps this goto in a retry (`toPass`): a navigation left on Playwright's
    *   30s default can consume the whole outer budget in one attempt, so the retry never
    *   gets a second try. Omit to keep the default.
    */
    async goto(url: string, isWait: boolean = true, waitUntil: 'load' | 'domcontentloaded' | 'commit' = 'load', timeout?: number): Promise<void> {
        await this.page.goto(url, { waitUntil: waitUntil, timeout: timeout });
    }
    async clickContinuous(): Promise<void> {
        await this.click(this.btnContinue);
        await this.wailForPageLoad();
    }
    async click(locator: Locator, options?: { timeout?: number }): Promise<void> {
        try {
            await locator.click(options);
        } catch (error) {
            throw new Error(`Failed to click on locator: ${this.describeLoactor(locator)}. Error: ${error}`);
        }


    }
    async wailForPageLoad(): Promise<void> {
        return this.page.waitForLoadState('load');
    }

    async fill(locator: Locator, value: string, options?: { timeout?: number }): Promise<void> {
        try {
            await locator.fill(value, options);
        } catch (error) {
            throw new Error(`Failed to fill locator: ${this.describeLoactor(locator)} with value: ${value}. Error: ${error}`);
        }

    }
    /**
     * Check Locator is visible or not
     * @param {Locator} locator
     * @param {number} timeout - ms to poll for the element to become enabled (default: no wait, single immediate check)
     * @returns
     */
    async isVisible(locator: Locator, timeout?: number): Promise<boolean> {
        return await locator.first().isVisible({ timeout: timeout });
    }
    /**
    * Get Text of Locator, if errors, return ''
    * @param {Locator} locator
    * @param {boolean} trim - Whether to trim whitespace (default: true)
    * @returns
    */
    async textContent(locator: Locator, trim: boolean = true): Promise<string> {

        const target = locator.first();
        if (!(await this.isVisible(target))) {
            return '';
        }
        const content = await target.textContent();
        return trim ? content?.trim() ?? '' : content ?? '';
    }

}
