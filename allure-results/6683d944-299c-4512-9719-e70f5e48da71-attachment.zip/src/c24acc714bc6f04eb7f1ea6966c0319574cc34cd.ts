import { Page } from '@playwright/test';
import { LoginLocator } from '../../locators/login-locators';
import { CommonPage } from './common-page';
import { User } from '../../interfaces/user';
import { AssertHelper } from '../../utilities/assert-helper';


export class LoginPage extends LoginLocator {

    commonPage: CommonPage;
    assertHelper: AssertHelper;
        constructor(page: Page) {
            super(page);
            this.commonPage = new CommonPage(page);
            this.assertHelper = new AssertHelper(page);
        }
    async login(user: User): Promise<void> {
        await this.commonPage.fill(this.inputUsername, user.username);
        await this.commonPage.fill(this.inputPassword, user.password);
        await this.commonPage.click(this.btnLogin);
    }

     async login1(username: string, password: string): Promise<void> {
        await this.commonPage.fill(this.inputUsername, username);
        await this.commonPage.fill(this.inputPassword, password);
        await this.commonPage.click(this.btnLogin);
    }
    async getLoginMessage(): Promise<string> {
        return await this.commonPage.textContent(this.lblLoginMessage);
    }

    async verifyLoginSuccess(): Promise<void> {
        // const loginMessage = await this.getLoginMessage();
        // return loginMessage.includes('Login successful');
        await this.assertHelper.expectToHaveURL(/appointment/);
    }
}
