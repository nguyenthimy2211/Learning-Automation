import { expect, Page } from "@playwright/test";

export class AssertHelper {
protected page: Page;
    constructor(page: Page) {
        this.page = page;
    }
    async expectToHaveURL(url: string | RegExp): Promise<void> {
        await expect(this.page).toHaveURL(url);

    }
}
