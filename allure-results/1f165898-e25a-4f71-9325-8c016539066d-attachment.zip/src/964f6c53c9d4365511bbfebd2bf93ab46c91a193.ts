import { test } from "../../../pages/base-page";



test.describe('Login Page Tests', () => {
    test('should login successfully with valid credentials', async ({ homePage, loginPage }) => {
        await homePage.goto();
        await homePage.clickMakeAppointment();
        await loginPage.login('John Doe', 'ThisIsNotAPassword');
        // Add assertions to verify successful login
    });
});
