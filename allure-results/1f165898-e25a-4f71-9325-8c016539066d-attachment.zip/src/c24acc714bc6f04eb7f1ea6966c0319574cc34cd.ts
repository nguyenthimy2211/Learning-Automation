import { Page } from '@playwright/test';
import { LoginLocator } from '../../locators/login-locators';
import { CommonPage } from './common-page';


export class LoginPage extends LoginLocator {

    commonPage: CommonPage;
        constructor(page: Page) {
            super(page);
            this.commonPage = new CommonPage(page);
        }
    async login(username: string, password: string): Promise<void> {
        await this.commonPage.fill(this.inputUsername, username);
        await this.commonPage.fill(this.inputPassword, password);
        await this.commonPage.click(this.btnLogin);
    }
}
